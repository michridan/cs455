Build: gcc main.c -o 455_proj1
Usage: Same as listed in project description