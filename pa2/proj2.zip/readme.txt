Build: gcc main.c -o 455_proj2
Usage: Same as listed in project description
