Build: gcc main.c -o 455_proj3
Usage: Same as in project description
